<?php
require_once "Persona.php";
class AlcoholicosAnonimos{
    public array $grupo = [];
    public function addPersona(Persona $persona){
        if(!$this->personaApuntada($persona)){
            array_push($this->grupo, $persona);
        }else{
            echo "Esta persona ya está apuntada<br>";
        }
        $this->guardarSesion();
    }
    public function setGrupo(array $personas):void{
        foreach($personas as $p){
            if(gettype($p) !== "Persona"){
                throw new Exception("Eso no es una persona: ". var_dump($p));
            }
            $this->addPersona($p);
        }
    }
    public function personaApuntada(Persona $persona):bool{
        if(count($this->grupo) == 0){
            return False;
        }else{
            foreach($this->grupo as $p){
                if($p->phoneNumber === $persona->phoneNumber){
                    return True;
                }
            }
            return False;
        }
    }

    private function getIndicePersona($persona):?int{
        foreach($this->grupo as $idx => $per){
            if($per->phoneNumber === $persona->phoneNumber){
                return $idx;
            }
        }
        return null;
    }

    public function borrar(Persona $persona): void{
        $indice = $this->getIndicePersona($persona);
        if(!$indice){
            echo "Esta persona no está en el grupo: $persona<br>";
        }else{
            array_splice($this->grupo, $indice, 1);
            $this->guardarSesion();
        }
    }

    public function __toString():string{
        $res = "{<br>";
        foreach($this->grupo as $i=>$p){
            $res .= "persona $i: $p,<br>" ;
        }
        return $res."}";

    }
    public function guardarSesion(){
        $_SESSION["grupo"] = $this;
    }
}