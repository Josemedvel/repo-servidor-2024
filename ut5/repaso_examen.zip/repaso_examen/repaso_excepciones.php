<?php
// crear excepciones nuevas a partir de otras
// lanzar excepciones
// capturar excepciones

class NuevaException extends Exception{
    public function __construct(string $mensaje){
        parent::__construct($mensaje);
    }
}

class ValorMenorA5Exception extends Exception{
    private string $mensajeBase = "El valor es menor a 5: ";
    public function __construct(int $valor){
        parent::__construct($this->mensajeBase . $valor);
    }
}

$var_1 = 10;
$var_2 = 6;
$res = $var_1 - $var_2;

try{
    if($res < 5){
        throw new ValorMenorA5Exception($res);
    }else{
        echo $res;
    }
}catch(ValorMenorA5Exception $e){
    echo $e->getMessage();
}
