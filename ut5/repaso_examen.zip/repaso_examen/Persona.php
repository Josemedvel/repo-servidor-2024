<?php
class Persona{
    public string $name;
    public string $lastName;
    public int $age;
    public string $phoneNumber;
    public function __construct(string $name, string $lastName, string $phoneNumber, int $age = 18){
        $this->name = $name;
        $this->lastName = $lastName;
        $this->phoneNumber = $phoneNumber;
        $this->age = $age;
    }
    public function __toString(){
        return "{nombre: $this->name, apellidos: $this->lastName, edad: $this->age, teléfono: $this->phoneNumber}";
    }
}