<?php
require_once "AlcoholicosAnonimos.php";
require_once "Persona.php";

session_start();

if(isset($_SESSION["grupo"])){
    $grupo = $_SESSION["grupo"];
}else{
    $grupo = new AlcoholicosAnonimos();
}
echo "<h2>Añadido de personas</h2>";
require_once "crearPersonaForm.html";

if($_SERVER["REQUEST_METHOD"] === "POST"){
    if(isset($_POST["annadirPersona"]) && isset($_POST["nombre"]) && isset($_POST["apellidos"]) && isset($_POST["telefono"])){ // estamos añadiendo
        $nombre = $_POST["nombre"];
        $apellidos = $_POST["apellidos"];
        $telefono = $_POST["telefono"];
        $edad = isset($_POST["edad"]) ? (int)$_POST["edad"] : 18;

        $personaNueva = new Persona($nombre, $apellidos, $telefono, $edad);
        $grupo->addPersona($personaNueva);
    }else if(isset($_POST["borrar"]) && isset($_POST["telefono"])){ // estamos borrando
        $telefono = $_POST["telefono"];
        $personaBorrar = new Persona("", "", $telefono);
        $grupo->borrar($personaBorrar);
    }
}

echo "<hr>";
echo "<h2>Borrado</h2>";
require_once "borrarPersonaForm.html";
echo $grupo;

